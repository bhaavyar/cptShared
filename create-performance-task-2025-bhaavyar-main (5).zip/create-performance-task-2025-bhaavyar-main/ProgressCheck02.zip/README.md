Upload all files to this folder.  You will start with index.html.
When your CPT is complete, the game or application should work without Wi-Fi connection (all materials are loaded here, and there is no need to access external sources).
