let questions = [
    {
        prompt: 'What are the names of the little pouches in the lungs responsible for gas exchange?',
        options: [
            "Alveoli",
            "Bronchioles",
            "Bronchi",
            "Lungs",
        ],
        answer: "Alveoli",
    },

    {
        prompt: 'What is the name of the long-term lung condition caused by damage to alveoli that results in shortness of breath?',
        options: [
            "Asthma",
            "Emphysema",
            "bronchitis",
            "stroke",
        ],
        answer: "Emphysema",
    },

    {
        prompt: 'Bronchitis is caused by the ____________ of bronchial tubes in the lungs',
        options: [
            "bleeding",
            "inflammation",
            "bursting",
            "rotting",
        ],
        answer: "inflammation",
    },

];

let questionsEl = document.querySelector("#questions");
let choicesEl = document.querySelector("#options");
let submitBtn = document.querySelector("#submit-score");
